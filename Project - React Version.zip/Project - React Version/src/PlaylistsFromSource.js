import React from 'react';

const PlaylistsFromSource = props=>{
    
    return <>
        <fieldset className="playlists-source">
            <form>
                <label htmlFor="playlistsFromSource">Playlist(s) from source service: </label>
            </form>
        </fieldset>
    </>
};

export default PlaylistsFromSource;