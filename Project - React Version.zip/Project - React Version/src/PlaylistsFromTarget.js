import React from 'react';

const PlaylistsFromTarget = props=>{
    
    return <>
        <fieldset className="playlists-target">
            <form>
                <label htmlFor="playlistsFromTarget">Playlist(s) from target service: </label>
                
            </form>
        </fieldset>
    </>
};

export default PlaylistsFromTarget;