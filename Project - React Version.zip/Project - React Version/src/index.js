import ReactDOM from 'react-dom';
import React from 'react';
import App from './App.js';
import './style.css';

ReactDOM.render(<App />, document.getElementById('react-container'));