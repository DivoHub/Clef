const express = require('express');
const app = express();

const server = app.listen(8080,()=>console.log('listening'));

app.use(express.static('public'));

app.set('view engine', 'ejs');
app.use(express.urlencoded({extended:true}));


app.get('/', (req,res)=>{
    res.render('index'); 
});